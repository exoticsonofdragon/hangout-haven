import os

TOKEN = os.environ.get("TOKEN")
NAME = "Hangout Haven Bot"
server = "https://guns.lol/javraj"
ch = "https://discord.com/channels/1363846156958044200/1381730023630700757"
OWNER_IDS = [1019329014369882123]
BotName = "Hangout Haven Bot"
serverLink = "https://bumpy.gg/guild/1363846156958044200/"